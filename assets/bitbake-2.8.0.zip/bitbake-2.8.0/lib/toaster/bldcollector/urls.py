#
# BitBake Toaster Implementation
#
# Copyright (C) 2014-2017   Intel Corporation
#
# SPDX-License-Identifier: GPL-2.0-only
#

from django.urls import re_path as url

import bldcollector.views

urlpatterns = [
        # landing point for pushing a bitbake_eventlog.json file to this toaster instace
        url(r'^eventfile$', bldcollector.views.eventfile, name='eventfile'),
]
