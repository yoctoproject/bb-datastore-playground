.. include:: <xhtml1-lat1.txt>
.. include:: <xhtml1-symbol.txt>

----

| |project_name|
| <docs@lists.yoctoproject.org>

Permission is granted to copy, distribute and/or modify this document under the
terms of the `Creative Commons Attribution-Share Alike 2.0 UK: England & Wales
<http://creativecommons.org/licenses/by-sa/2.0/uk/>`_ as published by Creative
Commons.

To report any inaccuracies or problems with this (or any other Yocto Project)
manual, or to send additions or changes, please send email/patches to the Yocto
Project documentation mailing list at ``docs@lists.yoctoproject.org`` or
log into the freenode ``#yocto`` channel.

