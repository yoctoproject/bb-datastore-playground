.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

======================================
Yocto Project Development Tasks Manual
======================================

|

.. toctree::
   :caption: Table of Contents
   :numbered:

   dev-manual-intro
   dev-manual-start
   dev-manual-common-tasks
   dev-manual-qemu
   history

.. include:: /boilerplate.rst
