.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

===================
Toaster User Manual
===================

|

.. toctree::
   :caption: Table of Contents
   :numbered:

   toaster-manual-intro
   toaster-manual-start
   toaster-manual-setup-and-use
   toaster-manual-reference
   history

.. include:: /boilerplate.rst
