.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

***********************
Manual Revision History
***********************

.. list-table::
   :widths: 10 15 40
   :header-rows: 1

   * - Revision
     - Date
     - Note
   * - 1.4
     - April 2013
     - The initial document released with the Yocto Project 1.4 Release
   * - 1.5
     - October 2013
     - Released with the Yocto Project 1.5 Release.
   * - 1.6
     - April 2014
     - Released with the Yocto Project 1.6 Release.
   * - 1.7
     - October 2014
     - Released with the Yocto Project 1.7 Release.
   * - 1.8
     - April 2015
     - Released with the Yocto Project 1.8 Release.
   * - 2.0
     - October 2015
     - Released with the Yocto Project 2.0 Release.
   * - 2.1
     - April 2016
     - Released with the Yocto Project 2.1 Release.
   * - 2.2
     - October 2016
     - Released with the Yocto Project 2.2 Release.
   * - 2.3
     - May 2017
     - Released with the Yocto Project 2.3 Release.
   * - 2.4
     - October 2017
     - Released with the Yocto Project 2.4 Release.
   * - 2.5
     - May 2018
     - Released with the Yocto Project 2.5 Release.
   * - 2.6
     - November 2018
     - Released with the Yocto Project 2.6 Release.
   * - 2.7
     - May 2019
     - Released with the Yocto Project 2.7 Release.
   * - 3.0
     - October 2019
     - Released with the Yocto Project 3.0 Release.
   * - 3.1
     - April 2020
     - Released with the Yocto Project 3.1 Release.
   * - 3.1.1
     - June 2020
     - Released with the Yocto Project 3.1.1 Release.
   * - 3.1.2
     - August 2020
     - Released with the Yocto Project 3.1.2 Release.
   * - 3.1.3
     - September 2020
     - Released with the Yocto Project 3.1.3 Release.
   * - 3.1.4
     - November 2020
     - Released with the Yocto Project 3.1.4 Release.
